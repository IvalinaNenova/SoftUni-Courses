﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=IVALINAS-LAPTOP;Database=MusicHub;Trusted_Connection=True";
    }
}
