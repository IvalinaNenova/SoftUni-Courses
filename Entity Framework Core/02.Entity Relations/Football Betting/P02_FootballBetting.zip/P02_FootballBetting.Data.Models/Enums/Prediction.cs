﻿namespace P02_FootballBetting.Data.Models.Enums
{
    public enum Prediction
    {
        Win = 1,
        Loose = 2,
        Draw = 3
    }
}
