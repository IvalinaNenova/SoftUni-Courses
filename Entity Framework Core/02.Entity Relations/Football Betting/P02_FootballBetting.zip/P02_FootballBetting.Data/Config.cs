﻿namespace P02_FootballBetting.Data
{
    public static class Config
    {
        public const string ConnectionString =
            @"Server=IVALINAS-LAPTOP;Database=FootballBookmakerSystem;Integrated Security=True;";
    }
}