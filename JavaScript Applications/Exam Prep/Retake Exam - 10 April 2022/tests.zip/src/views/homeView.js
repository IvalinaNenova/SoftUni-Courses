import { html } from '../../node_modules/lit-html/lit-html.js';

export const homeView = (ctx) => {
    ctx.page.redirect('/catalog')
}