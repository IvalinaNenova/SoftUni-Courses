﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Drones
{
    public class Airfield
    {
        private List<Drone> drones;
        private string name;
        private int capacity;
        private double landingStrip;

        public Airfield()
        {
            this.drones = new List<Drone>();
        }

        public Airfield(string name, int capacity, double landingStrip) : this()
        {
            this.name = name;
            this.capacity = capacity;
            this.landingStrip = landingStrip;
        }

        public int Count => drones.Count;
        public List<Drone> Drones => drones;
        public string Name
        {
            get => name;
            set => name = value;
        }
        public int Capacity
        {
            get => capacity;
            set => capacity = value;
        }

        public double LandingStrip
        {
            get => landingStrip;
            set => landingStrip = value;
        }

        //•	string AddDrone(Drone drone) - adds a drone to the drone's collection if there is room for it. Before adding a drone, check:
        public string AddDrone(Drone drone)
        {
            if (string.IsNullOrEmpty(drone.Name) ||
                string.IsNullOrEmpty(drone.Brand) ||
                drone.Range <= 5 ||
                drone.Range >= 15)
            {
                return "Invalid drone.";
            }

            if (Count == capacity)
            {
                return "Airfield is full.";
            }

            Drones.Add(drone);
            return $"Successfully added {drone.Name} to the airfield.";
        }
        //    •	If the name or brand are null or empty.
        //•	If the range is NOT between 5-15 kilometers.
        //    If the name, brand, or range properties are not valid, return: "Invalid drone.". If the airfield is full (there is no room for more drones), return "Airfield is full.". Otherwise, return: "Successfully added {droneName} to the airfield."
        public bool RemoveDrone(string name)
        {
            return drones.Remove(drones.Find(d => d.Name == name));
        }

        //•	int RemoveDroneByBrand(string brand) - removes all drones by the given brand, if such exists, return how many drones were removed, otherwise 0.
        public int RemoveDroneByBrand(string brand)
        {
            return drones.RemoveAll(d => d.Brand == brand);
        }

        //•	Drone FlyDrone(string name) method – fly (set its available property to false without removing it from the collection) the drone with the given name if exists. As a result return the drone, or null if does not exist.
        public Drone FlyDrone(string name)
        {
            Drone drone = drones.FirstOrDefault(d => d.Name == name);
            if (drone != null)
            {
                drone.Available = false;
                return drone;
            }

            return null;
        }

        //•	List<Drone> FlyDronesByRange(int range) method - fly and returns all drones which have a range equal or bigger to the given.Return a list of all drones which have been flown.The range will always be valid.
        public List<Drone> FlyDronesByRange(int range)
        {
            var drones = this.drones.FindAll(d => d.Range >= range);
            foreach (var drone in drones)
            {
                drone.Available = false;
            }

            return drones;
        }

        //•	Report() - returns information about the airfield and drones which are not in flight in the following format:	
        public string Report()
        {
            StringBuilder output = new StringBuilder();
            output.AppendLine($"Drones available at {Name}:");
            var filtered = drones.Where(d => d.Available == true);
            foreach (var drone in filtered)
            {
                output.AppendLine(drone.ToString());
            }
            return output.ToString();
        }
        //o	"Drones available at {airfieldName}:
        //{Drone1
        //}
        //{Drone2
        //}
        //(…)"


    }
}
