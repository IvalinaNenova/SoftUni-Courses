﻿using System;
using System.Collections.Generic;
using System.Text;
using Heroes.Models.Contracts;

namespace Heroes.Models.Weapons
{
    public abstract class Weapon : IWeapon
    {
        protected Weapon(string name, int durability)
        {
            
        }
        public string Name { get; }
        public int Durability { get; }
        public abstract int DoDamage();
    }
}
