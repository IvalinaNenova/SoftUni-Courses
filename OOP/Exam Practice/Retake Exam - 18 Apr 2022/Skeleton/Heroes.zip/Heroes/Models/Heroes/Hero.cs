﻿using System;
using System.Collections.Generic;
using System.Text;
using Heroes.Models.Contracts;

namespace Heroes.Models.Heroes
{
    public abstract class Hero : IHero
    {
        protected Hero(string name, int health, int armour)
        {
            
        }
        public string Name { get; }
        public int Health { get; }
        public int Armour { get; }
        public IWeapon Weapon { get; }
        public bool IsAlive { get; }
        public void TakeDamage(int points)
        {
            throw new NotImplementedException();
        }

        public void AddWeapon(IWeapon weapon)
        {
            throw new NotImplementedException();
        }
    }
}
