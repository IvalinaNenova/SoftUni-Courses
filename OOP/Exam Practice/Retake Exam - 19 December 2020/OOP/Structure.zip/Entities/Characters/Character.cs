﻿using System;

using WarCroft.Constants;
using WarCroft.Entities.Inventory;

namespace WarCroft.Entities.Characters.Contracts
{
    public abstract class Character
    {
		// TODO: Implement the rest of the class.
        protected Character(string name, double health, double armor, double abilityPoints, Bag bag)
        {
            
        }
		public string Name => throw new NotImplementedException();
		public double BaseHealth => throw new NotImplementedException();

		public double Health => throw new NotImplementedException();
		public double BaseArmor  => throw new NotImplementedException();
		public double Armor   => throw new NotImplementedException();
		public double AbilityPoints    => throw new NotImplementedException();

		public Bag Bag => throw new NotImplementedException();

		public bool IsAlive { get; set; } = true;

		protected void EnsureAlive()
		{
			if (!this.IsAlive)
			{
				throw new InvalidOperationException(ExceptionMessages.AffectedCharacterDead);
			}
		}
	}
}