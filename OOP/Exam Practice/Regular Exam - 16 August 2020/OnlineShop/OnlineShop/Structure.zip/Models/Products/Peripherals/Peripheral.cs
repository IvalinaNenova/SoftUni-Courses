﻿using System;

namespace OnlineShop.Models.Products.Peripherals
{
    public abstract class Peripheral : Product, IPeripheral
    {
        protected Peripheral(int id, string manufacturer, string model, decimal price, double overallPerformance, string connectionType)
            : base(id, manufacturer, model, price, overallPerformance)
        {
        }

        public string ConnectionType => throw new NotImplementedException();

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
