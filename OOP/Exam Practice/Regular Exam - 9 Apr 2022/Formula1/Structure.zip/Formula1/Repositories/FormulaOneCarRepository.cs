﻿using System;
using System.Collections.Generic;
using System.Text;
using Formula1.Models.Contracts;
using Formula1.Repositories.Contracts;

namespace Formula1.Repositories
{
    public class FormulaOneCarRepository : IRepository<IFormulaOneCar>
    {
        public IReadOnlyCollection<IFormulaOneCar> Models { get; }
        public void Add(IFormulaOneCar model)
        {
            throw new NotImplementedException();
        }

        public bool Remove(IFormulaOneCar model)
        {
            throw new NotImplementedException();
        }

        public IFormulaOneCar FindByName(string name)
        {
            throw new NotImplementedException();
        }
    }
}
