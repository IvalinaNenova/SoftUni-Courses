﻿using System;
using System.Collections.Generic;
using System.Text;
using Formula1.Models.Contracts;

namespace Formula1.Models
{
    public abstract class FormulaOneCar : IFormulaOneCar
    {
        protected FormulaOneCar(string model, int horsepower, double engineDisplacement)
        {
            
        }
        public string Model { get; }
        public int Horsepower { get; }
        public double EngineDisplacement { get; }
        public double RaceScoreCalculator(int laps)
        {
            throw new NotImplementedException();
        }
    }
}
