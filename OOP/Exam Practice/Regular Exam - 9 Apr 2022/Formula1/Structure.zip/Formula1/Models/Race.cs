﻿using System;
using System.Collections.Generic;
using System.Text;
using Formula1.Models.Contracts;

namespace Formula1.Models
{
    public class Race : IRace
    {
        public Race(string raceName, int numberOfLaps)
        {
            
        }
        public string RaceName { get; }
        public int NumberOfLaps { get; }
        public bool TookPlace { get; set; }
        public ICollection<IPilot> Pilots { get; }
        public void AddPilot(IPilot pilot)
        {
            throw new NotImplementedException();
        }

        public string RaceInfo()
        {
            throw new NotImplementedException();
        }
    }
}
