﻿using System;
using System.Collections.Generic;
using System.Text;
using EasterRaces.Models.Drivers.Contracts;

namespace EasterRaces.Repositories.Entities
{
    public class DriverRepository : Repository<IDriver>
    {
    }
}
