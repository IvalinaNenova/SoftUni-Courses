﻿using System;
using System.Collections.Generic;
using System.Text;
using EasterRaces.Models.Cars.Contracts;

namespace EasterRaces.Repositories.Entities
{
    public class CarRepository : Repository<ICar>
    {
    }
}
