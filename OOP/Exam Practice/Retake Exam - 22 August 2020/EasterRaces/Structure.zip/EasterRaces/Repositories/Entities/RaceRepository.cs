﻿using System;
using System.Collections.Generic;
using System.Text;
using EasterRaces.Models.Races.Contracts;

namespace EasterRaces.Repositories.Entities
{
    public class RaceRepository : Repository<IRace>
    {
    }
}
