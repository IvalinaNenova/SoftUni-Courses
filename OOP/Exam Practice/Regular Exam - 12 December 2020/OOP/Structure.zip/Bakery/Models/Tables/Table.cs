﻿using System;
using System.Collections.Generic;
using System.Text;
using Bakery.Models.BakedFoods;
using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables.Contracts;

namespace Bakery.Models.Tables
{
    public abstract class Table : ITable
    {
        private List<BakedFood> foodOrders = new List<BakedFood>();
        private List<Drink> drinkOrders = new List<Drink>();
        protected Table(int tableNumber, int capacity, decimal pricePerPerson)
        {
            
        }
        public int TableNumber => throw new NotImplementedException();

        public int Capacity => throw new NotImplementedException();

        public int NumberOfPeople => throw new NotImplementedException();

        public decimal PricePerPerson => throw new NotImplementedException();

        public bool IsReserved => throw new NotImplementedException();

        public decimal Price => throw new NotImplementedException();

        public void Reserve(int numberOfPeople)
        {
            throw new NotImplementedException();
        }

        public void OrderFood(IBakedFood food)
        {
            throw new NotImplementedException();
        }

        public void OrderDrink(IDrink drink)
        {
            throw new NotImplementedException();
        }

        public decimal GetBill()
        {
            throw new NotImplementedException();
        }

        public void Clear()
        {
            throw new NotImplementedException();
        }

        public string GetFreeTableInfo()
        {
            throw new NotImplementedException();
        }
    }
}
