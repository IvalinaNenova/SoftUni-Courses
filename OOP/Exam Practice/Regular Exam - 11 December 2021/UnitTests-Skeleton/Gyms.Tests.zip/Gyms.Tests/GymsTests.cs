﻿using System;
using NUnit.Framework;

namespace Gyms.Tests
{
    [TestFixture]
    public class GymsTests
    {
        [Test]
        [TestCase("")]
        [TestCase(null)]
        public void PropertyNameShouldThrowExceptionIfNameIsNullOrEmpty(string name)
        {
          Assert.Throws<ArgumentNullException>(()=> new Gym(name, 10));
        }

        [Test]
        public void PropertyCapacityShouldThrowExceptionIfNegativeNumberIsSet()
        {
            Assert.Throws<ArgumentException>(() => new Gym("Hercules", -1));
        }

        [Test]
        public void PropertyCapacityShouldReturnCapacityOfGym()
        {
            Gym fullGym = new Gym("Hercules", 4);

            fullGym.AddAthlete(new Athlete("Red"));
            fullGym.AddAthlete(new Athlete("Hot"));
            fullGym.AddAthlete(new Athlete("Chilli"));
            fullGym.AddAthlete(new Athlete("Pepper"));
            fullGym.RemoveAthlete("Red");
            fullGym.RemoveAthlete("Hot");

            Assert.AreEqual(4, fullGym.Capacity);
        }

        [Test]
        public void CountPropertyShouldReturnCountOfAthletesInGym()
        {
            Gym fullGym = new Gym("Hercules", 4);

            fullGym.AddAthlete(new Athlete("Red"));
            fullGym.AddAthlete(new Athlete("Hot"));
            fullGym.AddAthlete(new Athlete("Chilli"));
            fullGym.AddAthlete(new Athlete("Pepper"));

            fullGym.RemoveAthlete("Red");
            Assert.AreEqual(3, fullGym.Count);
        }

        [Test]
        public void AddAthleteMethodShouldThrowExceptionIfGymIsFull()
        {
            Gym fullGym = new Gym("Hercules", 4);

            fullGym.AddAthlete(new Athlete("Red"));
            fullGym.AddAthlete(new Athlete("Hot"));
            fullGym.AddAthlete(new Athlete("Chilli"));
            fullGym.AddAthlete(new Athlete("Pepper"));

            Assert.Throws<InvalidOperationException>(() => fullGym.AddAthlete(new Athlete("John")));
        }

        [Test]
        public void AddAthleteMethodShouldIncreaseCountOfAthletes()
        {
            Gym gym = new Gym("Power", 5);
            gym.AddAthlete(new Athlete("John"));
            Assert.AreEqual(1, gym.Count);
        }
        [Test]
        public void RemoveAthleteMethodShouldThrowExceptionIfAthleteDoesNotExist()
        {
            Gym fullGym = new Gym("Hercules", 4);

            fullGym.AddAthlete(new Athlete("Red"));
            fullGym.AddAthlete(new Athlete("Hot"));
            fullGym.AddAthlete(new Athlete("Chilli"));
            fullGym.AddAthlete(new Athlete("Pepper"));

            Assert.Throws<InvalidOperationException>(() => fullGym.RemoveAthlete("Peter"));
        }

        [Test]
        public void RemoveAthleteMethodShouldDecreaseCountOfAthletes()
        {
            Gym fullGym = new Gym("Hercules", 4);

            fullGym.AddAthlete(new Athlete("Red"));
            fullGym.AddAthlete(new Athlete("Hot"));
            fullGym.AddAthlete(new Athlete("Chilli"));
            fullGym.AddAthlete(new Athlete("Pepper"));

            fullGym.RemoveAthlete("Red");

            Assert.AreEqual(3, fullGym.Count);
        }
        [Test]
        public void InjureAthleteMethodShouldThrowExceptionIfAthleteDoesNotExist()
        {
            Gym fullGym = new Gym("Hercules", 4);

            fullGym.AddAthlete(new Athlete("Red"));
            fullGym.AddAthlete(new Athlete("Hot"));
            fullGym.AddAthlete(new Athlete("Chilli"));
            fullGym.AddAthlete(new Athlete("Pepper"));

            Assert.Throws<InvalidOperationException>(() => fullGym.InjureAthlete("Peter"));
        }

        [Test]
        public void InjureAthleteMethodShouldChangeAthleteInjureStatus()
        {
            Gym gym = new Gym("Power", 5);
            Athlete athlete = new Athlete("John");
            gym.AddAthlete(athlete);
            gym.InjureAthlete("John");

            Assert.AreEqual(true, athlete.IsInjured);
        }

        [Test]
        public void InjureAthleteMethodShouldReturnInjuredAthlete()
        {
            Gym gym = new Gym("Power", 5);
            Athlete athlete = new Athlete("John");
            gym.AddAthlete(athlete);
            Athlete injured = gym.InjureAthlete("John");

            Assert.AreEqual("John", athlete.FullName);
        }

        [Test]
        public void ReportMethodShouldShouldReturnInfoAboutTheGymAndAthletes()
        {
            Gym fullGym = new Gym("Hercules", 4);

            fullGym.AddAthlete(new Athlete("Red"));
            fullGym.AddAthlete(new Athlete("Hot"));
            fullGym.AddAthlete(new Athlete("Chilli"));
            fullGym.AddAthlete(new Athlete("Pepper"));

            fullGym.RemoveAthlete("Red");
            fullGym.InjureAthlete("Chilli");

            string report = fullGym.Report();

            Assert.AreEqual("Active athletes at Hercules: Hot, Pepper", report);
        }
    }
}
