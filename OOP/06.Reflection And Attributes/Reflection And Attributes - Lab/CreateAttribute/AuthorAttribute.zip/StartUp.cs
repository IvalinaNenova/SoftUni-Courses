﻿namespace AuthorProblem
{
    using System;
    [Author("Ivalina")]
    [Author("Diana")]
    public class StartUp
    {
        [Author("Marina")]
        [Author("Vanya")]
        static void Main()
        {

        }
    }
}
