﻿namespace AuthorProblem
{

    [Author("Ivalina")]
    public class StartUp
    {

        [Author("Marina")]
        static void Main(string[] args)
        {
        }
    }
}
