﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VehiclesExtension
{
    public enum AirConditionerMode
    {
        On, 
        Off
    }
}
