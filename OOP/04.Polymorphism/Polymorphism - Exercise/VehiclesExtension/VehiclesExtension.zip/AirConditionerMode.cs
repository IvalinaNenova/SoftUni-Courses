﻿namespace VehiclesExtension
{
    public enum AirConditionerMode
    {
        On,
        Off
    }
}
