﻿namespace WildFarm.Food
{
    public class Meat : Food
    {
        public Meat(int quantity)
            : base(quantity)
        {
        }
    }
}
