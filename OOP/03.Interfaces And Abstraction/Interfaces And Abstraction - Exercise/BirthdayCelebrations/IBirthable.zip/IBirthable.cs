﻿namespace BirthdayCelebrations
{
    public interface IBirthable
    {
        public string Birthday { get; set; }
    }
}
