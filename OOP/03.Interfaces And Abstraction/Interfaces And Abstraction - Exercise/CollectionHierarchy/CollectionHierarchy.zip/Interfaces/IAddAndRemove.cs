﻿namespace CollectionHierarchy.Interfaces
{
    public interface IAddAndRemove : IAddCollection
    {
        string Remove();
    }
}
