﻿namespace Telephony
{
    public interface IBrowse
    {
        void Browse(string site);
    }
}
