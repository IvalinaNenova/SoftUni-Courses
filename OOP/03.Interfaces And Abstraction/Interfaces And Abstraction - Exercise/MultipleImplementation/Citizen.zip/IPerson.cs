﻿namespace PersonInfo
{
    public interface IPerson
    {
        public string Name { get; set; }
        public int Age { get; set; }

    }
}
