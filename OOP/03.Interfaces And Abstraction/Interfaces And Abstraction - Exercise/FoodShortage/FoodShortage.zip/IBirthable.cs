﻿namespace FoodShortage
{
    public interface IBirthable
    {
        public string Birthday { get; set; }
    }
}
