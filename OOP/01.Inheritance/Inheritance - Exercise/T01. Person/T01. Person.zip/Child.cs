﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T01._Person
{
    public class Child : Person
    {
        public Child(string name, int age) : base(name, age)
        {
            Name = name;
            Age = age;
        }
    }
}
