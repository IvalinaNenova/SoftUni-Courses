﻿namespace PlanetWars.Models.MilitaryUnits
{
    public class SpaceForces : MilitaryUnit
    {
        public SpaceForces()
            : base(11)
        {
        }
    }
}
