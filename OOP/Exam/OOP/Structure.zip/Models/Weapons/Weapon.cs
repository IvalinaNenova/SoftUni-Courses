﻿using PlanetWars.Models.Weapons.Contracts;
using System;

namespace PlanetWars.Models.Weapons
{
    public abstract class Weapon : IWeapon
    {
        protected Weapon(int destructionLevel, double price)
        {

        }
        public double Price => throw new NotImplementedException();

        public int DestructionLevel => throw new NotImplementedException();
    }
}
