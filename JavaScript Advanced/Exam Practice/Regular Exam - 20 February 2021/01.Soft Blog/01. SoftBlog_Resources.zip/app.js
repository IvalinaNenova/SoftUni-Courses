function solve(){
   //Todo: Write your code here!
  }
